from django.apps import AppConfig


class ContractorConfig(AppConfig):
    name = 'contractor'
