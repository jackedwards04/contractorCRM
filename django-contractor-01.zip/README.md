# Version 0.1
* Implemented chat
* Fixed customer code entry
* Implemented personal contractor notes
* View project with code
* Create projects

# Version 0.0
* Choose between customer and contractor view
* Login/signup pages
* Code generation